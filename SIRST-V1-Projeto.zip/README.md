# SIRST V1 — First Signal / FU

Protótipo Android nativo (Android 8 ou superior). Reproduz arquivos de áudio locais indexados pelo Android. Não baixa músicas, não inclui catálogo, não usa internet e não contém anúncios.

## Gerar o APK pelo GitHub (sem instalar Android Studio)

1. Extraia este ZIP. Crie um repositório vazio no GitHub (pode ser privado).
2. Envie **o conteúdo da pasta extraída** à raiz do repositório, incluindo a pasta oculta `.github`. Os arquivos `settings.gradle`, `build.gradle` e a pasta `app` precisam estar na raiz.
3. Se a interface do GitHub não enviar a pasta oculta, crie manualmente o arquivo `.github/workflows/build.yml` no repositório e copie o conteúdo do arquivo de mesmo nome deste pacote.
4. Abra Actions → Gerar APK SIRST → Run workflow. O push para main/master também dispara a compilação.
5. Quando a execução terminar com sucesso, abra o resultado, desça até Artifacts e baixe `SIRST-V1-APK`. Extraia o ZIP resultante e instale `SIRST-V1.apk` no Android, usando a autorização de instalação de fonte externa somente para esse arquivo de teste, se o responsável pelo dispositivo permitir.

## Teste

- Abra SIRST e permita o acesso a músicas e áudio. O aplicativo lê o índice de áudio do Android, não modifica os arquivos de origem.
- Se nenhuma música aparecer, confirme que há arquivos de áudio locais acessíveis ao sistema (por exemplo em Music ou Download) e toque em ↻ para atualizar.
- Toque em uma música para iniciar a reprodução. Toque no mini player para abrir a tela de reprodução.
- Use + para criar playlists, ⋮ para adicionar faixas, ou abra a playlist e toque em + Músicas para escolher várias.
- Confira se as playlists continuam salvas depois de fechar e reabrir o aplicativo.
- Teste o controle pela notificação, a tela de bloqueio, busca, fila, modo aleatório e repetir faixa.

## Estado do protótipo

O código não foi compilado ou executado neste ambiente: não havia SDK Android nem acesso à internet para instalá-lo. O workflow está configurado para produzir um APK de depuração assinado pelo Gradle. A aparência usa tema escuro, verde menta e ícone próprio de onda sonora. Capas são marcadores gráficos nesta versão, não imagens extraídas dos álbuns. Não há equalizador, transição suave, letras, streaming, reprodução persistente após encerramento do processo nem edição de metadados. A reprodução em segundo plano e os controles de mídia foram implementados, mas ainda precisam de teste em aparelho real.

Dependências de compilação: Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, SDK 35. Sem bibliotecas externas em tempo de execução.
