package com.firstsignal.sirst;
import android.app.*;
import android.content.*;
import android.media.*;
import android.media.session.*;
import android.os.*;
import java.util.*;

public class PlayerService extends Service {
    public static final ArrayList<Track> queue = new ArrayList<>();
    public static int index=-1;
    public static boolean shuffle=false, repeat=false;
    public static MediaPlayer player;
    public static boolean ready=false;
    public static String error="";
    private MediaSession session;
    static Track current(){ return index>=0 && index<queue.size()?queue.get(index):null; }
    static boolean playing(){try{return ready && player!=null && player.isPlaying();}catch(Exception e){return false;}}
    static int position(){try{return ready && player!=null?player.getCurrentPosition():0;}catch(Exception e){return 0;}}
    static void seek(int p){try{if(ready && player!=null)player.seekTo(p);}catch(Exception ignored){}}
    static void command(Context c,String action){Intent i=new Intent(c,PlayerService.class).setAction(action); if("play".equals(action))c.startForegroundService(i);else c.startService(i);}
    static void select(Context c,List<Track> songs,int at){queue.clear();queue.addAll(songs);index=at;command(c,"play");}
    @Override public void onCreate(){super.onCreate();NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("playback","Reprodução SIRST",NotificationManager.IMPORTANCE_LOW));session=new MediaSession(this,"SIRST");session.setCallback(new MediaSession.Callback(){@Override public void onPlay(){resume();}@Override public void onPause(){pause();}@Override public void onSkipToNext(){next(1);}@Override public void onSkipToPrevious(){next(-1);}@Override public void onSeekTo(long p){seek((int)p);update();}});session.setActive(true);}
    @Override public int onStartCommand(Intent i,int flags,int id){if(i==null)return START_NOT_STICKY;String a=i.getAction();if("play".equals(a)){if(current()!=null){startForeground(1,notification());load();}else stopSelf();}else if("toggle".equals(a)){if(playing())pause();else resume();}else if("next".equals(a))next(1);else if("prev".equals(a))next(-1);else if("stop".equals(a)){stopSelf();}return START_NOT_STICKY;}
    private void release(){ready=false;if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}}
    private void load(){release();error="";Track t=current();if(t==null){stopSelf();return;}try{player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());player.setDataSource(this,t.uri);player.setOnPreparedListener(p->{if(p!=player)return;ready=true;resume();});player.setOnCompletionListener(p->{if(repeat){seek(0);resume();}else if(!shuffle && index==queue.size()-1){pause();seek(0);update();}else next(1);});player.setOnErrorListener((p,w,x)->{error="Não foi possível reproduzir este arquivo.";release();update();return true;});player.prepareAsync();update();}catch(Exception e){error="Não foi possível abrir este arquivo.";release();update();}}
    private void resume(){if(current()==null)return;if(player==null){startForeground(1,notification());load();return;}if(!ready)return;try{player.start();}catch(Exception ignored){}startForeground(1,notification());update();}
    private void pause(){try{if(playing())player.pause();}catch(Exception ignored){}update();}
    private void next(int d){if(queue.isEmpty())return;if(d<0 && position()>3000){seek(0);update();return;}if(shuffle && d>0 && queue.size()>1){index=(index+1+new Random().nextInt(queue.size()-1))%queue.size();}else index=(index+d+queue.size())%queue.size();load();}
    private PendingIntent action(String a,int n){return PendingIntent.getService(this,n,new Intent(this,PlayerService.class).setAction(a),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    private Notification notification(){Track t=current();PendingIntent open=PendingIntent.getActivity(this,5,new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"playback").setSmallIcon(R.drawable.ic_note).setContentTitle(t==null?"SIRST":t.title).setContentText(t==null?"Sua música, suas regras.":t.artist).setContentIntent(open).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(playing()).addAction(android.R.drawable.ic_media_previous,"Anterior",action("prev",1)).addAction(playing()?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play,playing()?"Pausar":"Tocar",action("toggle",2)).addAction(android.R.drawable.ic_media_next,"Próxima",action("next",3)).setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()).setShowActionsInCompactView(0,1,2)).build();}
    private void update(){Track t=current();if(t==null)return;session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE,t.title).putString(MediaMetadata.METADATA_KEY_ARTIST,t.artist).putLong(MediaMetadata.METADATA_KEY_DURATION,t.duration).build());session.setPlaybackState(new PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY|PlaybackState.ACTION_PAUSE|PlaybackState.ACTION_PLAY_PAUSE|PlaybackState.ACTION_SKIP_TO_NEXT|PlaybackState.ACTION_SKIP_TO_PREVIOUS|PlaybackState.ACTION_SEEK_TO).setState(playing()?PlaybackState.STATE_PLAYING:PlaybackState.STATE_PAUSED,position(),playing()?1f:0f).build());getSystemService(NotificationManager.class).notify(1,notification());}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){release();if(session!=null)session.release();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
