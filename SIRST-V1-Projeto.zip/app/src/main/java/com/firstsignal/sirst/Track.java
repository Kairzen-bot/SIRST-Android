package com.firstsignal.sirst;
import android.net.Uri;
final class Track {
    final String id, title, artist, album; final Uri uri; final long duration;
    Track(String id,String title,String artist,String album,Uri uri,long duration){this.id=id;this.title=title;this.artist=artist;this.album=album;this.uri=uri;this.duration=duration;}
}
